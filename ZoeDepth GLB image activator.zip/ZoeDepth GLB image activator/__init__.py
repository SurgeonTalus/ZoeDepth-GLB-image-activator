import bpy

def setup_material_with_attribute(obj, attribute_name="Color"):
    if not obj or not obj.data or not hasattr(obj.data, 'materials'):
        return
    
    mat = bpy.data.materials.get("GLB_Shader")
    if mat is None:
        mat = bpy.data.materials.new(name="GLB_Shader")
    mat.use_nodes = True
    
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    
    # Clear existing nodes
    for node in nodes:
        nodes.remove(node)
    
    # Create nodes
    principled = nodes.new(type="ShaderNodeBsdfPrincipled")
    principled.location = (0, 0)
    
    attribute_node = nodes.new(type="ShaderNodeAttribute")
    attribute_node.location = (-300, 0)
    attribute_node.attribute_name = attribute_name
    
    output_node = nodes.new(type="ShaderNodeOutputMaterial")
    output_node.location = (300, 0)
    
    # Connect nodes
    links.new(attribute_node.outputs['Color'], principled.inputs['Base Color'])
    links.new(principled.outputs['BSDF'], output_node.inputs['Surface'])
    
    # Assign material
    if len(obj.data.materials):
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)

def add_shader_to_selected():
    obj = bpy.context.object
    if obj and obj.type == 'MESH':
        setup_material_with_attribute(obj)
    else:
        print("No valid mesh object selected.")

def menu_func(self, context):
    self.layout.operator("object.add_glb_shader", text="Apply ZoeDepth image on GLB file")

class OBJECT_OT_AddGLBShader(bpy.types.Operator):
    """Add GLB Shader with Attribute"""
    bl_idname = "object.add_glb_shader"
    bl_label = "Add GLB Shader"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        add_shader_to_selected()
        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_AddGLBShader)
    bpy.types.VIEW3D_MT_object.append(menu_func)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_AddGLBShader)
    bpy.types.VIEW3D_MT_object.remove(menu_func)

if __name__ == "__main__":
    register()
